import java.io.*;
import java.util.*;

public class Main {
    private static ArrayList<Person> people = new ArrayList<>();
    private static ArrayList<Appointment> apps = new ArrayList<>();

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        loadDoctorsFromFile("doctors.txt");

        int menuChoice = 0;
        while (menuChoice != 5) {
            System.out.println("\n=== SMART CARE HOSPITAL SYSTEM ===");
            System.out.println("1. Add Patient");
            System.out.println("2. Create Appointment");
            System.out.println("3. Show Appointments");
            System.out.println("4. Update Appointment Status (Dynamic)");
            System.out.println("5. Exit & Save Appointments");
            System.out.print("Choose: ");

            try {
                menuChoice = in.nextInt();
                in.nextLine();
            } catch (Exception e) {
                System.out.println("Numbers only!");
                in.nextLine();
                continue;
            }

            switch (menuChoice) {
                case 1:
                    System.out.print("ID: "); String id = in.nextLine();
                    System.out.print("Name: "); String name = in.nextLine();
                    System.out.print("Phone: "); String ph = in.nextLine();
                    System.out.print("Blood: "); String bl = in.nextLine();
                    System.out.print("Record: "); String rec = in.nextLine();

                    Patient p = new Patient(id, name, ph, bl, rec);
                    people.add(p);
                    System.out.println("Added successfully.");
                    break;

                case 2:
                    ArrayList<Doctor> docs = getDoctors();
                    ArrayList<Patient> pats = getPatients();

                    if (docs.isEmpty() || pats.isEmpty()) {
                        System.out.println("No doctors or patients available! Add patients or check doctors file.");
                        break;
                    }

                    System.out.println("\nSelect Doctor:");
                    for (int i = 0; i < docs.size(); i++) {
                        System.out.println(i + ") " + docs.get(i).getpName() + " (" + docs.get(i).getSpec() + ")");
                    }
                    System.out.print("Choose Doctor Index: ");
                    int dIdx = in.nextInt();

                    System.out.println("\nSelect Patient:");
                    for (int i = 0; i < pats.size(); i++) {
                        System.out.println(i + ") " + pats.get(i).getpName() + " [Code: " + pats.get(i).getPatCode() + "]");
                    }
                    System.out.print("Choose Patient Index: ");
                    int pIdx = in.nextInt();
                    in.nextLine();

                    System.out.print("Date (dd-mm): "); String d = in.nextLine();
                    System.out.print("Time (hh:mm): "); String t = in.nextLine();

                    try {
                        if (dIdx < 0 || dIdx >= docs.size() || pIdx < 0 || pIdx >= pats.size()) {
                            System.out.println("Invalid doctor or patient selection!");
                            break;
                        }

                        Doctor selectedD = docs.get(dIdx);
                        Patient selectedP = pats.get(pIdx);

                        for (Appointment a : apps) {
                            if (a.getDoc().getDocCode().equals(selectedD.getDocCode())
                                    && a.getAppDate().equals(d)
                                    && a.getAppTime().equals(t)) {
                                throw new DoctorUnavailableException("Doctor " + selectedD.getpName() + " is busy at " + t + " on " + d + "!");
                            }
                        }

                        Appointment newA = new Appointment(selectedD, selectedP, d, t);
                        apps.add(newA);
                        System.out.println("\nBooked Successfully! Status is: Scheduled");
                        newA.printTicket();

                    } catch (DoctorUnavailableException e) {
                        System.out.println("Booking Error: " + e.getMessage());
                    } catch (Exception e) {
                        System.out.println("Something went wrong during booking!");
                    }
                    break;

                case 3:
                    if (apps.isEmpty()) {
                        System.out.println("No appointments yet.");
                    } else {
                        System.out.println("\n--- ALL APPOINTMENTS ---");
                        for (Appointment a : apps) {
                            a.printTicket();
                            System.out.println("------------------------");
                        }
                    }
                    break;

                case 4:
                    if (apps.isEmpty()) {
                        System.out.println("No appointments to update!");
                        break;
                    }
                    System.out.println("\nSelect Appointment to Update:");
                    for (int i = 0; i < apps.size(); i++) {
                        System.out.println(i + ") " + apps.get(i).getAppCode() + " [Current State: " + apps.get(i).getCurrentStatus() + "]");
                    }
                    System.out.print("Enter Number: ");
                    int appIdx = in.nextInt();
                    in.nextLine();

                    if (appIdx >= 0 && appIdx < apps.size()) {
                        System.out.println("Select New State:");
                        System.out.println("1. In-Progress");
                        System.out.println("2. Completed");
                        System.out.print("Choose: ");
                        int stateChoice = in.nextInt();
                        in.nextLine();

                        if (stateChoice == 1) {
                            apps.get(appIdx).setCurrentStatus("In-Progress");
                            System.out.println("Status updated to In-Progress!");
                        } else if (stateChoice == 2) {
                            apps.get(appIdx).setCurrentStatus("Completed");
                            System.out.println("Status updated to Completed!");
                        } else {
                            System.out.println("Invalid choice!");
                        }
                    } else {
                        System.out.println("Invalid appointment number!");
                    }
                    break;

                case 5:
                    saveAppointmentsToFile("appointments.txt");
                    System.out.println("Data saved. Goodbye!");
                    break;

                default:
                    System.out.println("Wrong choice!");
            }
        }
        in.close();
    }

    private static void loadDoctorsFromFile(String fileName) {
        File file = new File(fileName);
        if (!file.exists()) {
            try (PrintWriter pw = new PrintWriter(file)) {
                pw.println("111,Dr. Sami,0599,3000.0,45,Eyes,50.0");
                pw.println("222,Dr. Ola,0598,3200.0,40,Children,45.0");
            } catch (IOException e) {
                System.out.println("Error initializing doctors file.");
            }
        }

        try (Scanner fileScanner = new Scanner(file)) {
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] data = line.split(",");
                if (data.length == 7) {
                    Doctor doc = new Doctor(
                            data[0].trim(),
                            data[1].trim(),
                            data[2].trim(),
                            Double.parseDouble(data[3].trim()),
                            Integer.parseInt(data[4].trim()),
                            data[5].trim(),
                            Double.parseDouble(data[6].trim())
                    );
                    people.add(doc);
                }
            }
            System.out.println("Doctors loaded successfully from file!");
        } catch (FileNotFoundException e) {
            System.out.println("Doctors file not found!");
        } catch (Exception e) {
            System.out.println("Error parsing doctors file data!");
        }
    }

    private static void saveAppointmentsToFile(String fileName) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(fileName))) {
            for (Appointment a : apps) {
                pw.println(a.toFileFormat());
            }
            System.out.println("Appointments successfully exported to " + fileName);
        } catch (IOException e) {
            System.out.println("Error saving appointments: " + e.getMessage());
        }
    }

    private static ArrayList<Doctor> getDoctors() {
        ArrayList<Doctor> docs = new ArrayList<>();
        for (Person p : people) {
            if (p instanceof Doctor) {
                docs.add((Doctor) p);
            }
        }
        return docs;
    }

    private static ArrayList<Patient> getPatients() {
        ArrayList<Patient> pats = new ArrayList<>();
        for (Person p : people) {
            if (p instanceof Patient) {
                pats.add((Patient) p);
            }
        }
        return pats;
    }
}