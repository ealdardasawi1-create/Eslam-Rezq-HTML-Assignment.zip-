public class Doctor extends Employee {
    private String docCode;
    private String spec;
    private double fee;
    private static int docCounter = 800;

    public Doctor(String id, String name, String phone, double salary, int hours, String spec, double fee) {
        super(id, name, phone, salary, hours);
        this.docCode = "DR-" + (docCounter++);
        this.spec = spec;
        this.fee = fee;
    }

    public Doctor(String id, String name, String phone, double salary, int hours, String spec) {
        this(id, name, phone, salary, hours, spec, 40.0);
    }

    @Override
    public void displayInfo() {
        System.out.println("[ DR. INFO ]");
        System.out.println("ID: " + docCode);
        super.displayInfo();
        System.out.println("Specialist: " + spec);
        System.out.println("Price: " + fee + " NIS");
    }

    public String getDocCode() {
        return docCode;
    }
    public String getSpec() {
        return spec;
    }
    public void setSpec(String spec) {
        this.spec = spec;
    }
    public double getFee() {
        return fee;
    }
    public void setFee(double fee) {
        this.fee = fee;
    }
}