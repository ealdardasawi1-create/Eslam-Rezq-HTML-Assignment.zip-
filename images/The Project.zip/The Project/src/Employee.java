public class Employee extends Person {
    private double salary;
    private int hours;

    public Employee(String id, String name, String phone, double salary, int hours) {
        super(id, name, phone);
        this.salary = salary;
        this.hours = hours;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Net Salary: " + salary + " NIS");
        System.out.println("Work Hours: " + hours);
    }

    public double getSalary() {
        return salary;
    }
    public void setSalary(double salary) {
        this.salary = salary;
    }
    public int getHours() {
        return hours;
    }
    public void setHours(int hours) {
        this.hours = hours;
    }
}