public class Nurse extends Employee {
    private String nurseCode;
    private String room;
    private String dept;
    private static int nurseCounter = 900;

    public Nurse(String id, String name, String phone, double salary, int hours, String room, String dept) {
        super(id, name, phone, salary, hours);
        this.nurseCode = "NS-" + (nurseCounter++);
        this.room = room;
        this.dept = dept;
    }

    @Override
    public void displayInfo() {
        System.out.println("[ NURSE INFO ]");
        System.out.println("ID: " + nurseCode);
        super.displayInfo();
        System.out.println("Room No: " + room);
        System.out.println("Section: " + dept);
    }

    public String getNurseCode() {
        return nurseCode;
    }
    public String getRoom() {
        return room;
    }
    public void setRoom(String room) {
        this.room = room;
    }
    public String getDept() {
        return dept;
    }
    public void setDept(String dept) {
        this.dept = dept;
    }
}