import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class HospitalGUI extends JFrame {

    private ArrayList<Person> people = new ArrayList<>();
    private ArrayList<Appointment> apps = new ArrayList<>();

    private JComboBox<String> docCombo = new JComboBox<>();
    private JComboBox<String> patCombo = new JComboBox<>();

    private JComboBox<String> dayCombo = new JComboBox<>(new String[]{"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"});
    private JComboBox<String> monthCombo = new JComboBox<>(new String[]{"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"});
    private JComboBox<String> timeCombo = new JComboBox<>(new String[]{"08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00"});

    private JComboBox<String> pBloodCombo = new JComboBox<>(new String[]{"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"});
    private JComboBox<String> pHistoryCategory = new JComboBox<>(new String[]{"None", "Chronic Disease", "Allergy", "Previous Surgery", "Other"});
    private JTextField pHistoryDetails = new JTextField(10);

    private JComboBox<String> phonePrefixCombo = new JComboBox<>(new String[]{"970", "972"});

    private JTextArea outputArea = new JTextArea(10, 40);

    public HospitalGUI() {
        loadDoctorsFromFile("doctors.txt");

        setTitle("Smart Care Hospital Management System");
        setSize(800, 580);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));

        JPanel addPatientPanel = new JPanel(new GridLayout(7, 2, 5, 5));
        addPatientPanel.setBorder(BorderFactory.createTitledBorder("Add New Patient"));

        JTextField pId = new JTextField();
        JTextField pName = new JTextField();
        JTextField pPhone = new JTextField();
        JButton addPatientBtn = new JButton("Add Patient");

        JPanel phonePanel = new JPanel(new BorderLayout(2, 0));
        phonePanel.add(phonePrefixCombo, BorderLayout.WEST);
        phonePanel.add(pPhone, BorderLayout.CENTER);

        pHistoryDetails.setEnabled(false);

        pHistoryCategory.addActionListener(e -> {
            String selected = pHistoryCategory.getSelectedItem().toString();
            if (selected.equals("None")) {
                pHistoryDetails.setEnabled(false);
                pHistoryDetails.setText("");
            } else {
                pHistoryDetails.setEnabled(true);
                pHistoryDetails.requestFocus();
            }
        });

        addPatientPanel.add(new JLabel("ID:")); addPatientPanel.add(pId);
        addPatientPanel.add(new JLabel("Name:")); addPatientPanel.add(pName);
        addPatientPanel.add(new JLabel("Phone:")); addPatientPanel.add(phonePanel);
        addPatientPanel.add(new JLabel("Blood Type:")); addPatientPanel.add(pBloodCombo);
        addPatientPanel.add(new JLabel("History Category:")); addPatientPanel.add(pHistoryCategory);
        addPatientPanel.add(new JLabel("History Details:")); addPatientPanel.add(pHistoryDetails);
        addPatientPanel.add(new JLabel("")); addPatientPanel.add(addPatientBtn);

        JPanel bookingPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        bookingPanel.setBorder(BorderFactory.createTitledBorder("Book Appointment"));

        JButton bookBtn = new JButton("Book Appointment");

        JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 0));
        datePanel.add(dayCombo);
        datePanel.add(new JLabel("-"));
        datePanel.add(monthCombo);

        bookingPanel.add(new JLabel("Doctor:")); bookingPanel.add(docCombo);
        bookingPanel.add(new JLabel("Patient:")); bookingPanel.add(patCombo);
        bookingPanel.add(new JLabel("Date (dd-mm):")); bookingPanel.add(datePanel);
        bookingPanel.add(new JLabel("Time (hh:mm):")); bookingPanel.add(timeCombo);
        bookingPanel.add(new JLabel("")); bookingPanel.add(bookBtn);

        leftPanel.add(addPatientPanel);
        leftPanel.add(bookingPanel);

        JPanel rightPanel = new JPanel(new BorderLayout(10, 10));

        JPanel topButtons = new JPanel(new FlowLayout());
        JButton showAppsBtn = new JButton("Show All Appointments");
        JButton saveBtn = new JButton("Save & Exit");
        topButtons.add(showAppsBtn);
        topButtons.add(saveBtn);

        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);

        rightPanel.add(topButtons, BorderLayout.NORTH);
        rightPanel.add(scrollPane, BorderLayout.CENTER);

        add(leftPanel, BorderLayout.WEST);
        add(rightPanel, BorderLayout.CENTER);

        updateCombos();

        addPatientBtn.addActionListener(e -> {
            String idText = pId.getText().trim();
            String nameText = pName.getText().trim();
            String phoneDigits = pPhone.getText().trim();

            if (nameText.isEmpty()) {
                outputArea.setText("⚠️ Please enter patient name!");
                return;
            }

            if (idText.isEmpty() || !idText.matches("\\d+") || idText.length() > 9) {
                outputArea.setText("⚠️ Invalid ID! Must be numbers only and maximum 9 digits.");
                return;
            }

            if (!phoneDigits.matches("\\d{9}")) {
                outputArea.setText("⚠️ Invalid Phone! Must be exactly 9 digits after the prefix.");
                return;
            }

            String fullPhone = phonePrefixCombo.getSelectedItem().toString() + phoneDigits;

            String blood = pBloodCombo.getSelectedItem().toString();
            String category = pHistoryCategory.getSelectedItem().toString();
            String details = pHistoryDetails.getText().trim();
            String finalHistory;

            if (category.equals("None")) {
                finalHistory = "None";
            } else if (details.isEmpty()) {
                finalHistory = category;
            } else {
                finalHistory = category + ": " + details;
            }

            Patient p = new Patient(idText, nameText, fullPhone, blood, finalHistory);
            people.add(p);
            updateCombos();
            outputArea.setText("✅ Patient (" + nameText + ") added successfully!\nPhone: " + fullPhone);

            pId.setText(""); pName.setText(""); pPhone.setText("");
            phonePrefixCombo.setSelectedIndex(0);
            pBloodCombo.setSelectedIndex(0);
            pHistoryCategory.setSelectedIndex(0);
            pHistoryDetails.setText("");
        });

        bookBtn.addActionListener(e -> {
            try {
                int dIndex = docCombo.getSelectedIndex();
                int pIndex = patCombo.getSelectedIndex();

                if (dIndex < 0 || pIndex < 0) {
                    outputArea.setText("⚠️ Please select doctor and patient!");
                    return;
                }

                Doctor selectedD = getDoctors().get(dIndex);
                Patient selectedP = getPatients().get(pIndex);

                String d = dayCombo.getSelectedItem() + "-" + monthCombo.getSelectedItem();
                String t = timeCombo.getSelectedItem().toString();

                for (Appointment a : apps) {
                    if (a.getDoc().getDocCode().equals(selectedD.getDocCode())
                            && a.getAppDate().equals(d)
                            && a.getAppTime().equals(t)) {
                        throw new DoctorUnavailableException("Doctor " + selectedD.getpName() + " is busy at " + t + "!");
                    }
                }

                Appointment newApp = new Appointment(selectedD, selectedP, d, t);
                apps.add(newApp);
                outputArea.setText("✅ Appointment Booked Successfully!\n" +
                        "Code: " + newApp.getAppCode() + " | Doctor: " + selectedD.getpName() + " | Patient: " + selectedP.getpName());

            } catch (DoctorUnavailableException ex) {
                outputArea.setText("❌ Exception: " + ex.getMessage());
            } catch (Exception ex) {
                outputArea.setText("❌ Something went wrong!");
            }
        });

        showAppsBtn.addActionListener(e -> {
            if (apps.isEmpty()) {
                outputArea.setText("No appointments booked yet.");
            } else {
                StringBuilder sb = new StringBuilder("=== ALL APPOINTMENTS ===\n");
                for (Appointment a : apps) {
                    sb.append(a.getAppCode()).append(" | ").append(a.getAppDate()).append(" ").append(a.getAppTime())
                            .append(" | Dr: ").append(a.getDoc().getpName()).append(" | Pat: ").append(a.getPat().getpName())
                            .append(" | Status: ").append(a.getCurrentStatus()).append("\n");
                }
                outputArea.setText(sb.toString());
            }
        });

        saveBtn.addActionListener(e -> {
            saveAppointmentsToFile("appointments.txt");
            JOptionPane.showMessageDialog(this, "Data saved to appointments.txt!");
            System.exit(0);
        });
    }

    private void updateCombos() {
        docCombo.removeAllItems();
        for (Doctor d : getDoctors()) {
            docCombo.addItem(d.getpName() + " (" + d.getSpec() + ")");
        }

        patCombo.removeAllItems();
        for (Patient p : getPatients()) {
            patCombo.addItem(p.getpName() + " [" + p.getPatCode() + "]");
        }
    }

    private ArrayList<Doctor> getDoctors() {
        ArrayList<Doctor> docs = new ArrayList<>();
        for (Person p : people) if (p instanceof Doctor) docs.add((Doctor) p);
        return docs;
    }

    private ArrayList<Patient> getPatients() {
        ArrayList<Patient> pats = new ArrayList<>();
        for (Person p : people) if (p instanceof Patient) pats.add((Patient) p);
        return pats;
    }

    private void loadDoctorsFromFile(String fileName) {
        File file = new File(fileName);
        if (!file.exists()) {
            try (PrintWriter pw = new PrintWriter(file)) {
                pw.println("111,Dr. Sami,0599,3000.0,45,Eyes,50.0");
                pw.println("222,Dr. Ola,0598,3200.0,40,Children,45.0");
            } catch (IOException ignored) {}
        }
        try (Scanner fileScanner = new Scanner(file)) {
            while (fileScanner.hasNextLine()) {
                String[] data = fileScanner.nextLine().split(",");
                if (data.length == 7) {
                    people.add(new Doctor(data[0].trim(), data[1].trim(), data[2].trim(),
                            Double.parseDouble(data[3].trim()), Integer.parseInt(data[4].trim()),
                            data[5].trim(), Double.parseDouble(data[6].trim())));
                }
            }
        } catch (Exception ignored) {}
    }

    private void saveAppointmentsToFile(String fileName) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(fileName))) {
            for (Appointment a : apps) {
                pw.println(a.toFileFormat());
            }
        } catch (IOException ignored) {}
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new HospitalGUI().setVisible(true));
    }
}