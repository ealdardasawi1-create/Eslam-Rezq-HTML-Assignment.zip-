public class Appointment {
    private static int counter = 100;
    private String appCode;
    private Doctor doc;
    private Patient pat;
    private String appDate;
    private String appTime;
    private String currentStatus;

    public Appointment(Doctor doc, Patient pat, String appDate, String appTime) {
        this.appCode = "APP-" + (++counter);
        this.doc = doc;
        this.pat = pat;
        this.appDate = appDate;
        this.appTime = appTime;
        this.currentStatus = "Scheduled";
    }

    public String getAppCode() {
        return appCode;
    }
    public Doctor getDoc() {
        return doc;
    }
    public Patient getPat() {
        return pat;
    }
    public String getAppDate() {
        return appDate;
    }
    public String getAppTime() {
        return appTime;
    }
    public String getCurrentStatus() {
        return currentStatus;
    }
    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    public String toFileFormat() {
        return appCode + "," + appDate + "," + appTime + ","
                + doc.getDocCode() + "," + pat.getPatCode() + "," + currentStatus;
    }

    public void printTicket() {
        System.out.println("Code: " + appCode);
        System.out.println("Doctor: " + doc.getpName() + " (" + doc.getSpec() + ")");
        System.out.println("Patient: " + pat.getpName());
        System.out.println("Date/Time: " + appDate + " at " + appTime);
        System.out.println("Status: " + currentStatus);
    }
}