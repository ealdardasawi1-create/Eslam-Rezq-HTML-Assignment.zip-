public class Person {
    private String pId;
    private String pName;
    private String pPhone;

    public Person(String id, String name, String phone) {
        this.pId = id;
        this.pName = name;
        this.pPhone = phone;
    }

    public void displayInfo() {
        System.out.println("ID NO: " + pId);
        System.out.println("NAME: " + pName);
        System.out.println("TEL: " + pPhone);
    }

    public String getpId() {
        return pId;
    }
    public void setpId(String id) {
        this.pId = id;
    }

    public String getpName() {
        return pName;
    }
    public void setpName(String name) {
        this.pName = name;
    }

    public String getpPhone() {
        return pPhone;
    }
    public void setpPhone(String phone) {
        this.pPhone = phone;
    }
}