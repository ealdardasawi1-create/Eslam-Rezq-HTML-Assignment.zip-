public class Patient extends Person {
    private String patCode;
    private String bloodGroup;
    private String history;
    private static int counter = 700;

    public Patient(String id, String name, String phone, String bloodGroup, String history) {
        super(id, name, phone);
        this.patCode = "PT-" + (counter++);
        this.bloodGroup = bloodGroup;
        this.history = history;
    }

    public Patient(String id, String name, String phone, String bloodGroup) {
        this(id, name, phone, bloodGroup, "None");

    }

    @Override
    public void displayInfo() {
        System.out.println("* Patient Data *");
        System.out.println("Code: " + patCode);
        super.displayInfo(); // R3: super
        System.out.println("Blood: " + bloodGroup);
        System.out.println("Medical Case: " + history);
    }

    public String getPatCode() {
        return patCode;
    }
    public String getBloodGroup() {
        return bloodGroup;
    }
    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }
    public String getHistory() {
        return history;
    }
    public void setHistory(String history) {
        this.history = history;
    }
}